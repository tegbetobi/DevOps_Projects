---
title: Streamlit Shopper
emoji: 🚀
colorFrom: red
colorTo: red
sdk: docker
app_port: 8501
tags:
- streamlit
pinned: false
short_description: Streamlit template space
---

---
title: Streamlit Shopper Insight App
emoji: 🛍️
colorFrom: pink
colorTo: purple
sdk: streamlit
sdk_version: "1.35.0"
app_file: main.py
pinned: false
---

