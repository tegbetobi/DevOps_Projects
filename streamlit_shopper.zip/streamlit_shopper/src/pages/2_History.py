import streamlit as st

def history_page():
    """
    This function is for displaying previously processed receipts.

    Note: Not implemented yet.
    """
    st.title("History")
    st.info("No history available yet.")

history_page()